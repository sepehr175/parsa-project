import SectionHeading from "./SectionHeading";

const columns = [
  "Feature / UX Element",
  "AAQ Properties",
  "Portico",
  "Baron & Cabot",
  "API Global",
  "Verta Property",
  "Samuel Dawson",
];

const rows = [
  [
    "Self-Serve Financial Calculators (Mortgage, Yield, Stamp Duty, ROI)",
    "High (Dedicated suite)",
    "Partial (Valuation only)",
    "Partial (Basic yield)",
    "Minimal",
    "Low",
    "Low",
  ],
  [
    "Cross-Border Relocation Services (Immigration & Education)",
    "Yes (Integrated)",
    "No",
    "No",
    "No",
    "No",
    "No",
  ],
  [
    "Full Lifecycle Support (Acquire → Manage → Exit)",
    "Yes",
    "Partial",
    "Partial",
    "Yes",
    "Partial",
    "Partial",
  ],
  [
    "Educational & Localized Guides",
    "Yes",
    "Partial",
    "Yes",
    "Yes",
    "Low",
    "Low",
  ],
  [
    "Modern, Scannable UI (Non-Cluttered)",
    "High",
    "Medium",
    "Low",
    "High",
    "Medium",
    "Medium",
  ],
];

export default function FeatureComparison() {
  return (
    <section>
      <SectionHeading>Feature & UX Capability Comparison</SectionHeading>
      <div className="overflow-x-auto">
        <div className="min-w-[1100px]">
          <div className="grid grid-cols-[288px_162px_162px_162px_162px_162px_162px] bg-[#0b172d] text-white rounded-t-2xl">
            {columns.map((c) => (
              <div key={c} className="p-6 text-sm font-semibold">
                {c}
              </div>
            ))}
          </div>
          {rows.map((row, i) => (
            <div
              key={row[0]}
              className={`grid grid-cols-[288px_162px_162px_162px_162px_162px_162px] ${
                i % 2 === 1 ? "bg-[#f6f7f9]" : "bg-white"
              } ${i === rows.length - 1 ? "rounded-b-2xl" : ""}`}
            >
              {row.map((cell, j) => (
                <div
                  key={j}
                  className={`p-6 text-sm ${
                    j === 0
                      ? "font-semibold text-[#202631]"
                      : j === 1
                      ? "font-semibold text-[#0b172d]"
                      : "text-[#4b5563]"
                  }`}
                >
                  {cell}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
