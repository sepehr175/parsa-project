import SectionHeading from "./SectionHeading";

const steps = [
  {
    num: "01",
    title: "Discovery & Research",
    subtitle: 'Understanding the "Why"',
    items: [
      "Competitor Benchmarking",
      "User Interviews & Surveys",
      "Key Insights & Pain Points",
      "Personas & Empathy Maps",
    ],
  },
  {
    num: "02",
    title: "Strategy & Definition",
    subtitle: "Scoping the Solution",
    items: [
      "Problem Framing",
      "Information Architecture (IA)",
      "User Journey Mapping & Task Flows",
      "Feature Prioritization",
    ],
  },
  {
    num: "03",
    title: "Ideation & Wireframing",
    subtitle: "Exploration & Structure",
    items: [
      "Low-Fidelity Sketches & Wireframes",
      "Mid-Fidelity Prototypes",
      "Concept Iterations",
    ],
  },
  {
    num: "04",
    title: "Design System & UI Design",
    subtitle: "Exploration & Structure",
    items: [
      "Design System & Foundations",
      "High-Fidelity Visual Design",
      "Micro-interactions & States",
      "Responsive Layouts",
    ],
  },
  {
    num: "05",
    title: "Testing, Launch & Impact",
    subtitle: "Validation & Results",
    items: [
      "Usability Testing & Feedback",
      "Design-to-Development Handoff",
      "Key Metrics & Outcomes",
      "Reflection & Next Steps",
    ],
  },
];

export default function DesignProcess() {
  return (
    <section>
      <SectionHeading>Design Process</SectionHeading>
      <div className="flex flex-col gap-2">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-[2px]">
          {steps.map((step) => (
            <div
              key={step.num}
              className="bg-[#0b172d] text-white flex flex-col gap-2 px-4 py-4 relative"
              style={{
                clipPath:
                  "polygon(0 0, calc(100% - 14px) 0, 100% 50%, calc(100% - 14px) 100%, 0 100%, 14px 50%)",
              }}
            >
              <p className="text-[18px] leading-7">{step.num}</p>
              <p className="text-sm font-bold leading-5">{step.title}</p>
              <p className="text-xs leading-[18px] text-white/80">{step.subtitle}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-[2px]">
          {steps.map((step) => (
            <div
              key={step.num}
              className="bg-[#f6f7f9] rounded-b-3xl p-4 flex flex-col gap-3 text-xs text-[#202631]"
            >
              {step.items.map((item) => (
                <p key={item}>{item}</p>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
