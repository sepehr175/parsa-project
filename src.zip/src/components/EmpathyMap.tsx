import SectionHeading from "./SectionHeading";

type Quad = {
  name: string;
  thinks: string[];
  feels: string[];
  says: string[];
  does: string[];
  pains: string[];
  gains: string[];
};

const quads: Quad[] = [
  {
    name: "Tariq Al-Mansoor",
    thinks: [
      "Is this market as stable as everyone claims?",
      "Will property management eat up all my net yield?",
      "I need pure transparency—no hidden developer fees.",
    ],
    feels: [
      "Cautious about cross-border legal compliance.",
      "Skeptical of aggressive sales reps.",
      "Empowered when given clear data and self-serve tools.",
    ],
    says: [
      "I don't have time to fix tenant issues.",
      "Show me the net ROI after UK taxes.",
      "I need a fully managed, hands-off setup.",
    ],
    does: [
      "Stress-tests numbers using online models.",
      "Compares UK cities against Dubai/EU yields.",
      "Requests brochures and data-heavy decks.",
    ],
    pains: [
      "Currency volatility and UK tax friction.",
      "Inability to inspect sites physically.",
      "Lack of clear, real-time reporting.",
    ],
    gains: [
      "Reliable passive cash flow in GBP.",
      "Long-term capital security for his family.",
      "Complete peace of mind via end-to-end mgmt.",
    ],
  },
  {
    name: "Priya & Vikram Sharma",
    thinks: [
      "Are we choosing the right neighborhood for schools?",
      "What if our visa timeline clashes with completion?",
      "Buying seems safer than sinking money into rent.",
    ],
    feels: [
      "Anxious and overwhelmed by multiple parallel tasks.",
      "Protective of their children's future education.",
      "Relieved when encountering structured, clear guides.",
    ],
    says: [
      "We need a home close to top universities",
      "Who can help us manage visas and buying?",
      "We need someone to walk us through this.",
    ],
    does: [
      "Cross-references school ratings & postcodes.",
      "Reads regional UK city investment guides.",
      "Books consultations that bundle services.",
    ],
    pains: [
      "Navigating visa and property laws at once.",
      "Unfamiliarity with UK conveyancing.",
      "Fear of overpaying in unfamiliar areas.",
    ],
    gains: [
      "A secure, owned family home upon arrival.",
      "Seamless integration of schooling & visa.",
      "One trusted partner handling everything.",
    ],
  },
  {
    name: "James Bennett",
    thinks: [
      "Interest rate shifts are squeezing my cash margins.",
      "Is now the right time to sell or should I refinance?",
      "Most high-street agents don't understand exit math.",
    ],
    feels: [
      "Frustrated with rising regulatory red tape.",
      "Pragmatic and laser-focused on financial metrics.",
      "Decisive once accurate scenario modeling is shown.",
    ],
    says: [
      "I need to unlock equity for other assets",
      "What is the most tax-efficient exit?",
      "I want an agent who understands numbers.",
    ],
    does: [
      "Runs rental yield & mortgage stress tests.",
      "Audits existing portfolio performance.",
      "Looks for specialized portfolio exit sales.",
    ],
    pains: [
      "Changing UK tax laws eroding net returns.",
      "Sluggish sales cycles tying up capital.",
      "Ineffective, generic estate agents.",
    ],
    gains: [
      "Maximized capital release upon disposal.",
      "Streamlined portfolio with lower overhead.",
      "Clear exit timeline and yield clarity.",
    ],
  },
];

function Quadrant({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="flex-1 p-6">
      <h4 className="text-lg font-bold text-[#202631] mb-4">{title}</h4>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {items.map((item) => (
          <div
            key={item}
            className="bg-[#f6f7f9] rounded-xl p-4 text-xs text-[#202631] leading-5 min-h-[96px] flex items-center"
          >
            {item}
          </div>
        ))}
      </div>
    </div>
  );
}

function ListBlock({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="flex-1 p-6">
      <h4 className="text-lg font-bold text-[#202631] mb-4">{title}</h4>
      <ul className="flex flex-col gap-2 text-sm text-[#4b5563]">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function EmpathyMapCard({ q }: { q: Quad }) {
  return (
    <div className="border border-[#eceef1] rounded-3xl overflow-hidden relative">
      <div className="absolute left-1/2 top-6 -translate-x-1/2 w-16 h-16 rounded-full bg-[#0b172d] text-white flex items-center justify-center text-xs font-bold z-10">
        {q.name
          .split(" ")
          .map((n) => n[0])
          .slice(0, 2)
          .join("")}
      </div>
      <p className="text-center pt-24 pb-2 text-sm font-semibold text-[#202631]">{q.name}</p>
      <div className="flex flex-col sm:flex-row border-t border-[#eceef1]">
        <Quadrant title="Thinks" items={q.thinks} />
        <div className="w-px bg-[#eceef1] hidden sm:block" />
        <Quadrant title="Feels" items={q.feels} />
      </div>
      <div className="flex flex-col sm:flex-row border-t border-[#eceef1]">
        <Quadrant title="Says" items={q.says} />
        <div className="w-px bg-[#eceef1] hidden sm:block" />
        <Quadrant title="Does" items={q.does} />
      </div>
      <div className="flex flex-col sm:flex-row border-t border-[#eceef1]">
        <ListBlock title="Pains" items={q.pains} />
        <div className="w-px bg-[#eceef1] hidden sm:block" />
        <ListBlock title="Gains" items={q.gains} />
      </div>
    </div>
  );
}

export default function EmpathyMap() {
  return (
    <section>
      <SectionHeading>Empathy Map</SectionHeading>
      <div className="flex flex-col gap-12">
        {quads.map((q) => (
          <EmpathyMapCard key={q.name} q={q} />
        ))}
      </div>
    </section>
  );
}
