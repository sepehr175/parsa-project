import SectionHeading from "./SectionHeading";

const dots = [
  { label: "Portico (Local Estate Agency)", x: 24.8, y: 25.7, align: "left" as const },
  { label: "API Global (Global Institutional Platform)", x: 75.2, y: 21.6, align: "right" as const },
  { label: "Baron & Cabot (Brochureware & Luxury Advisory)", x: 75.2, y: 59.4, align: "right" as const },
  {
    label: "Samuel Dawson Property (Brochureware & Luxury Advisory)",
    x: 70.8,
    y: 76.2,
    align: "right" as const,
  },
  { label: "Verta Property (Boutique Sourcing)", x: 24.8, y: 63.4, align: "left" as const },
];

const opportunities = [
  {
    title: "Interactive Transparency First",
    body: "Placing un-gated Mortgage, Rental Yield, Stamp Duty, and ROI calculators directly on the site positions AAQ as a utility-first advisory rather than a high-pressure sales broker.",
  },
  {
    title: 'Unified "Living + Investing" Ecosystem',
    body: "Integrating ancillary services (Immigration Support and University Applications) under one roof solves the complete relocation friction point for international family investors.",
  },
  {
    title: "Institutional Credibility with Modern Simplicity",
    body: "Pairing clean editorial layouts with clear social proof ($240m+ GDV, 1,000+ units) eliminates the visual clutter seen in legacy UK brokerage portals.",
  },
];

export default function StrategicPositioning() {
  return (
    <section>
      <SectionHeading>AAQ Properties Strategic Positioning & UX Opportunities</SectionHeading>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Quadrant chart */}
        <div className="bg-[#f6f7f9] rounded-3xl p-8">
          <div className="relative w-full aspect-square">
            <p className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-semibold text-[#202631] text-center w-2/3">
              High Digital Interactivity & Tools
            </p>
            <p className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs font-semibold text-[#202631] text-center w-2/3">
              Static / Form-Gated Experience
            </p>
            <p className="absolute top-1/2 -left-2 -translate-y-1/2 -translate-x-full text-xs font-semibold text-[#202631] w-24 text-right pr-2">
              Local / UK-Only Focus
            </p>
            <p className="absolute top-1/2 -right-2 -translate-y-1/2 translate-x-full text-xs font-semibold text-[#202631] w-24 pl-2">
              Global / Expat Focus
            </p>

            <div className="absolute inset-0 border border-[#d7dbe3] rounded-2xl bg-white">
              <div className="absolute left-1/2 top-0 bottom-0 w-px bg-[#d7dbe3]" />
              <div className="absolute top-1/2 left-0 right-0 h-px bg-[#d7dbe3]" />

              {dots.map((d) => (
                <div
                  key={d.label}
                  className="absolute flex items-center gap-2"
                  style={{
                    left: `${d.x}%`,
                    top: `${d.y}%`,
                    transform: "translate(-50%, -50%)",
                    flexDirection: d.align === "right" ? "row" : "row-reverse",
                  }}
                >
                  <span className="w-3 h-3 rounded-full bg-[#0b172d] shrink-0" />
                  <span
                    className={`text-[11px] leading-tight text-[#202631] w-32 ${
                      d.align === "right" ? "text-left" : "text-right"
                    }`}
                  >
                    {d.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Opportunities */}
        <div className="flex flex-col gap-8">
          {opportunities.map((o) => (
            <div key={o.title} className="flex flex-col gap-3">
              <h3 className="text-xl font-bold text-[#202631]">{o.title}</h3>
              <p className="text-sm text-[#4b5563] leading-6">{o.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
