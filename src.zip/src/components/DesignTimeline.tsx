import SectionHeading from "./SectionHeading";

const weeks = ["Week 1-2", "Week 3-4", "Week 5-6", "Week 7-8"];

const phases = [
  { label: "Discovery & Research", offset: 0 },
  { label: "Strategy & Information Architecture", offset: 1 },
  { label: "UI Design & Design System", offset: 2 },
  { label: "Testing, Handoff & Launch", offset: 3 },
];

const details = [
  [
    "Stakeholder alignment & goal setting",
    "Competitor benchmarking & market analysis",
    "User interviews, surveys, and pain-point synthesis",
    "Personas and primary user journey maps",
  ],
  [
    '"How Might We" framing & core feature prioritization',
    "Sitemap creation and content hierarchy modeling",
    "Primary user flows (e.g., calculation workflows, inquiry funnels)",
    "Low-fidelity wireframing and initial concept validation",
  ],
  [
    "Design system foundation (typography scale, color tokens, grid structure)",
    "High-fidelity responsive screen design (desktop & mobile)",
    "Interactive component states, micro-interactions, and input validation",
    "Clickable prototype assembly for testing",
  ],
  [
    "Usability testing sessions & design refinements",
    "Developer handoff, component token documentation, and asset exports",
    "QA design review against staging builds",
    "Post-launch monitoring and analytics setup",
  ],
];

export default function DesignTimeline() {
  return (
    <section>
      <SectionHeading>Design Timeline</SectionHeading>

      <div className="grid grid-cols-4 gap-2 mb-2">
        {weeks.map((w) => (
          <p key={w} className="text-sm font-semibold text-[#202631] px-2">
            {w}
          </p>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-2 mb-10">
        {phases.map((phase) => (
          <div
            key={phase.label}
            className="col-span-2"
            style={{
              gridColumnStart: phase.offset + 1,
              marginTop: phase.offset * 28,
            }}
          >
            <div className="h-14 rounded-full bg-[#0b172d]" />
            <p className="text-xs font-medium text-[#202631] mt-2 px-2">{phase.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {details.map((col, i) => (
          <div key={i} className="flex flex-col gap-3 text-sm text-[#202631]">
            {col.map((item) => (
              <p key={item}>{item}</p>
            ))}
          </div>
        ))}
      </div>
    </section>
  );
}
