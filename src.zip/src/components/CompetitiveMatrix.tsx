import SectionHeading from "./SectionHeading";

const columns = [
  "Competitor",
  "Market Positioning",
  "UX Strengths",
  "UX Weaknesses & Gaps",
  "Key Value Offerings",
];

const rows = [
  [
    "Portico",
    "Traditional London estate agency & lettings manager",
    "Clean typography, hyper-local branch search, instant online property valuation tool.",
    "Traditional agency feel; heavily London-centric with limited cross-border investor tooling.",
    "Sales, lettings, maintenance, Airbnb management.",
  ],
  [
    "Baron & Cabot",
    "Global advisory for UK off-plan & buy-to-let investments",
    "Strong educational focus (guides, webinars), high emphasis on global investor trust.",
    "Text-heavy landing pages, aggressive sales gating before value delivery, cluttered UI.",
    "Sourcing, mortgage support, international buyer guides.",
  ],
  [
    "API Global",
    "B2B/B2C global property investment distributor",
    "Institutional credibility, clear global footprint metrics, polished enterprise UI.",
    "Geared primarily toward institutional funds & master brokers; less personalized B2C journey.",
    "End-to-end distribution, portfolio optimization, lettings.",
  ],
  [
    "Verta Property",
    "Commission-free UK property sourcing agency",
    'Transparent fee narrative ("free for investors"), approachable tone of voice.',
    "Lacks self-serve interactive tools; relies heavily on standard contact forms for discovery.",
    "Deal sourcing, project coordination, full-cycle handoff.",
  ],
  [
    "Samuel Dawson Property",
    "Luxury London & Dubai cross-border specialist",
    "High-end visual aesthetic, luxury branding, prime asset focus (Emaar, Berkeley).",
    "Complex input fields or confusing UK tax terminology.",
    "Long, multi-field lead forms creating friction.",
  ],
];

export default function CompetitiveMatrix() {
  return (
    <section>
      <SectionHeading>Competitive Landscape Matrix</SectionHeading>
      <div className="overflow-x-auto">
        <div className="min-w-[900px]">
          <div className="grid grid-cols-[200px_266px_266px_266px_266px] bg-[#0b172d] text-white rounded-t-2xl">
            {columns.map((c) => (
              <div key={c} className="p-6 text-sm font-semibold">
                {c}
              </div>
            ))}
          </div>
          {rows.map((row, i) => (
            <div
              key={row[0]}
              className={`grid grid-cols-[200px_266px_266px_266px_266px] ${
                i % 2 === 1 ? "bg-[#f6f7f9]" : "bg-white"
              } ${i === rows.length - 1 ? "rounded-b-2xl" : ""}`}
            >
              {row.map((cell, j) => (
                <div
                  key={j}
                  className={`p-6 text-sm ${
                    j === 0 ? "font-semibold text-[#202631]" : "text-[#4b5563]"
                  }`}
                >
                  {cell}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
