import SectionHeading from "./SectionHeading";

type Persona = {
  name: string;
  role: string;
  initials: string;
  age: string;
  location: string;
  job: string;
  investmentProfile: string;
  motivations: string;
  painPoints: string[];
  touchpoints: string[];
};

const personas: Persona[] = [
  {
    name: "Tariq Al-Mansoor",
    role: "The Overseas Wealth Builder",
    initials: "TA",
    age: "42",
    location: "Dubai, UAE",
    job: "Senior Tech Director",
    investmentProfile: "Capital growth & passive rental income (£300k–£600k budget)",
    motivations:
      "Diversifying capital into stable UK real estate markets (London commuter belt, Manchester, Birmingham) without dealing with daily landlord operations.",
    painPoints: [
      "Cross-border complexity (currency exchange, UK stamp duty, non-resident taxes).",
      "Distrust of opaque agent fees and exaggerated ROI promises.",
      "Inability to physically inspect developments or manage tenant issues.",
    ],
    touchpoints: [
      "Instant ROI & Stamp Duty Calculators for multi-scenario modeling.",
      "Hands-Off Rental Management service pages.",
      "High-level market research & city guides.",
    ],
  },
  {
    name: "Priya & Vikram Sharma",
    role: "The Relocating Family",
    initials: "PV",
    age: "38 & 40",
    location: "Mumbai, India → Relocating to London",
    job: "Financial Analyst & Consultant",
    investmentProfile: "First-time UK buyer / Owner-occupier to long-term hold (£450k–£750k budget)",
    motivations:
      "Securing a home close to top universities/schools while navigating relocation, visas, and purchasing simultaneously.",
    painPoints: [
      "Overwhelmed by navigating UK visa rules, university admissions, and property searches concurrently.",
      "Unclear on local neighborhood dynamics, school catchment zones, and resale potential.",
    ],
    touchpoints: [
      "Purchasing & Consultancy structured step-by-step guidance.",
      "Immigration & University Application ancillary advisory services.",
      "Localized City & Investment Guides.",
    ],
  },
  {
    name: "James Bennett",
    role: "The Domestic Portfolio Optimizer",
    initials: "JB",
    age: "51",
    location: "Bristol, UK (Domestic Portfolio Landlord)",
    job: "Business Owner",
    investmentProfile: "Portfolio rebalancing & capital realization (5+ properties)",
    motivations:
      "Maximizing net yield amidst changing interest rates and executing well-timed asset disposals to fund new commercial ventures.",
    painPoints: [
      "Changing tax legislation and shifting mortgage rates eroding margins.",
      "Frustration with generic estate agents who lack strategic exit planning capabilities.",
    ],
    touchpoints: [
      "Mortgage & Rental Yield Calculators for portfolio stress-testing.",
      "Exit Strategy & Sales consultation requests.",
      "Market News & Insights feeds.",
    ],
  },
];

function PersonaCard({ p }: { p: Persona }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[380px_1fr] rounded-3xl overflow-hidden border border-[#eceef1]">
      <div className="bg-[#0b172d] flex items-center justify-center py-16 lg:py-0">
        <div className="w-28 h-28 rounded-full bg-white/10 flex items-center justify-center text-white text-3xl font-bold">
          {p.initials}
        </div>
      </div>
      <div className="p-10 flex flex-col gap-8">
        <div>
          <h3 className="text-2xl sm:text-3xl font-bold text-[#202631]">{p.name}</h3>
          <p className="text-lg text-[#4b5563] mt-1">{p.role}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex flex-col gap-6">
            <div className="flex flex-col gap-2 text-sm">
              <div className="flex justify-between border-b border-[#eceef1] pb-2">
                <span className="text-[#4b5563]">Age</span>
                <span className="font-medium text-[#202631]">{p.age}</span>
              </div>
              <div className="flex justify-between border-b border-[#eceef1] pb-2">
                <span className="text-[#4b5563]">Location</span>
                <span className="font-medium text-[#202631] text-right">{p.location}</span>
              </div>
              <div className="flex justify-between border-b border-[#eceef1] pb-2">
                <span className="text-[#4b5563]">Job</span>
                <span className="font-medium text-[#202631] text-right">{p.job}</span>
              </div>
            </div>
            <div>
              <h4 className="font-bold text-[#202631] mb-2">Investment Profile</h4>
              <p className="text-sm text-[#4b5563] leading-6">{p.investmentProfile}</p>
            </div>
            <div>
              <h4 className="font-bold text-[#202631] mb-2">Motivations</h4>
              <p className="text-sm text-[#4b5563] leading-6">{p.motivations}</p>
            </div>
          </div>

          <div className="flex flex-col gap-6">
            <div>
              <h4 className="font-bold text-[#202631] mb-2">Core Pain Points</h4>
              <ul className="flex flex-col gap-2 text-sm text-[#4b5563] leading-6 list-disc list-inside">
                {p.painPoints.map((pt) => (
                  <li key={pt}>{pt}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-[#202631] mb-2">Platform Touchpoints</h4>
              <ul className="flex flex-col gap-2 text-sm text-[#4b5563] leading-6 list-disc list-inside">
                {p.touchpoints.map((pt) => (
                  <li key={pt}>{pt}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function UserPersonas() {
  return (
    <section>
      <SectionHeading>User Personas</SectionHeading>
      <div className="flex flex-col gap-8">
        {personas.map((p) => (
          <PersonaCard key={p.name} p={p} />
        ))}
      </div>
    </section>
  );
}
