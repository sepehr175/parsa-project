import SectionHeading from "./SectionHeading";

type Stage = {
  stage: string;
  action: string;
  emoji: string;
  feeling: string;
  thinking: string;
  touchpoints: string;
  pain: string;
  opportunity: string;
};

type Journey = {
  name: string;
  role: string;
  scenario: string;
  goal: string;
  stages: Stage[];
};

const journeys: Journey[] = [
  {
    name: "Tariq Al-Mansoor",
    role: "The Overseas Wealth Builder",
    scenario:
      "Tariq wants to deploy capital into high-yield UK residential property from Dubai without managing tenants or navigating cross-border tax traps manually.",
    goal: "Validate returns, model net ROI after taxes, and engage a fully managed, hands-off service.",
    stages: [
      {
        stage: "1. Discovery",
        action: "Clicks on a UK investment guide or targeted ad highlighting high-yield regional markets.",
        emoji: "😐",
        feeling: "Skeptical",
        thinking: '"Are these yields realistic, or is it another sales pitch?"',
        touchpoints: "Social ad / Google search / Landing page",
        pain: "Opaque fee structures on competing sites.",
        opportunity: 'Clear value proposition: "Smarter by Design, Hands-Off by Default."',
      },
      {
        stage: "2. Research & Evaluation",
        action: 'Lands on AAQ Properties; reviews the "About Us" track record ($240m+ GDV secured, 1,000+ units).',
        emoji: "🙂",
        feeling: "Intrigued",
        thinking: '"The metrics look institutional and professional, not like a pushy high-street broker."',
        touchpoints: "Homepage hero, Stats strip, Service cards",
        pain: "Unclear if the firm handles non-resident UK buyers.",
        opportunity: "Prominently display international credentials and end-to-end service coverage.",
      },
      {
        stage: "3. Interaction & Calculation",
        action:
          "Navigates to ROI & Stamp Duty Calculators; inputs purchase price, deposit, and projected rental income.",
        emoji: "🧐",
        feeling: "Empowered & Analytical",
        thinking: '"Can I see my net cash flow after non-resident Stamp Duty and management fees?"',
        touchpoints: "Interactive ROI & Stamp Duty calculator tools",
        pain: "Complex input fields or confusing UK tax terminology.",
        opportunity: "Instant, dynamic calculation summaries with visual charts and pre-set tax defaults.",
      },
      {
        stage: "4. Commitment / Action",
        action: "Selects Rental Management & Purchasing; submits a high-intent consultation request.",
        emoji: "😎",
        feeling: "Confident & Decisive",
        thinking: '"I want to talk directly to someone who handles the entire lifecycle end-to-end."',
        touchpoints: "Service landing page CTA, Lead capture form",
        pain: "Long, multi-field lead forms creating friction.",
        opportunity: "2-step frictionless lead form with preferred contact method (WhatsApp/Zoom).",
      },
      {
        stage: "5. Post-Action & Retention",
        action: "Receives tailored investment prospectus; schedules discovery call via WhatsApp/Calendar.",
        emoji: "😊",
        feeling: "Reassured & Satisfied",
        thinking: '"If onboarding is smooth, I\'ll allocate more capital to future phases."',
        touchpoints: "Follow-up email, CRM dashboard, Consultation",
        pain: "Slow response times from overseas advisors.",
        opportunity: "Automated email confirmation with customized PDF summary of calculated numbers.",
      },
    ],
  },
  {
    name: "Priya & Vikram Sharma",
    role: "The Relocating Family",
    scenario:
      "Priya & Vikram are relocating from Mumbai to the UK for their children's education and need to purchase a property while sorting out schooling and visa logistics.",
    goal: "Find an area with top school catchments, understand buying steps, and bundle property advisory with relocation support.",
    stages: [
      {
        stage: "1. Discovery",
        action: 'Searches for "buying home near UK top universities / South East relocation."',
        emoji: "😰",
        feeling: "Overwhelmed & Anxious",
        thinking: '"Moving is chaotic. how do we coordinate buying a home and university admissions together?"',
        touchpoints: "Organic search / Blog / City Guides",
        pain: "Fragmented advice across separate lawyers, agents, and school consultants.",
        opportunity: 'Position integrated advisory: "Property + Relocation + Education Assistance."',
      },
      {
        stage: "2. Research & Evaluation",
        action: "Browses City Guides and News & Insights; checks the breadth of services.",
        emoji: "😌",
        feeling: "Relieved & Interested",
        thinking: '"They don\'t just sell homes; they assist with immigration and universities too."',
        touchpoints: "City Guide sub-pages, Navigation menu",
        pain: "Unfamiliarity with UK postcodes and school catchment zones.",
        opportunity: "Interactive city guide cards highlighting universities, transport links, and lifestyle.",
      },
      {
        stage: "3. Interaction & Calculation",
        action: "Uses Mortgage & Stamp Duty Calculators; explores University Application & Immigration Services.",
        emoji: "🧐",
        feeling: "Informed & Focused",
        thinking: '"What is our total cash requirement upfront including legal and stamp duty?"',
        touchpoints: "Service detail pages, Interactive calculators",
        pain: "Confusion over international buyer mortgage eligibility.",
        opportunity: "Calculator disclaimer notes clarifying non-resident mortgage loan-to-value (LTV) limits.",
      },
      {
        stage: "4. Commitment / Action",
        action: "Submits a multi-service advisory request on the Consultancy page.",
        emoji: "💪",
        feeling: "Reassured & Proactive",
        thinking: '"Having one partner manage both property and relocation will save us months."',
        touchpoints: "Multi-service inquiry modal / Contact form",
        pain: "Unclear if ancillary services can be bundled with property search.",
        opportunity: 'Checkbox selectors allowing users to bundle "Property + Visa/University Support" in one form.',
      },
      {
        stage: "5. Post-Action & Retention",
        action: "Attends a comprehensive consultation covering property sourcing, visas, and school admissions.",
        emoji: "🏡",
        feeling: "Protected & Supported",
        thinking: '"We feel supported across all aspects of our family\'s move."',
        touchpoints: "Discovery video call, Resource onboarding kit",
        pain: "Fear of missing university admission or completion deadlines.",
        opportunity: "Structured onboarding checklist showing milestone timelines for both property and schooling.",
      },
    ],
  },
  {
    name: "James Bennett",
    role: "The Domestic Portfolio Optimizer",
    scenario:
      "James is an experienced UK landlord whose profit margins are squeezed by interest rate hikes; he needs to audit yields and strategically sell underperforming units.",
    goal: "Model current rental yields against mortgage costs, evaluate exit timing, and instruct an agent specialized in portfolio disposals.",
    stages: [
      {
        stage: "1. Discovery",
        action: "Searches for portfolio exit strategies or reads an industry market report.",
        emoji: "😤",
        feeling: "Frustrated with Market",
        thinking: '"I need to reallocate capital, high-street estate agents don\'t understand portfolio tax math."',
        touchpoints: "LinkedIn / Real Estate News / Search",
        pain: "Generic agents treating portfolio sales like single-family residential listings.",
        opportunity: 'Highlight specialized "Exit Strategy & Sales" directly in the top-level navigation.',
      },
      {
        stage: "2. Research & Evaluation",
        action: "Evaluates AAQ's Exit Strategy & Sales and Consultancy service pages.",
        emoji: "🧐",
        feeling: "Analytical & Selective",
        thinking: '"Do these advisors have genuine commercial and disposal experience?"',
        touchpoints: "Service page (Exit Strategy), Case studies",
        pain: "Lack of strategic exit frameworks on competitor websites.",
        opportunity: "Provide real-world case studies detailing GDV achieved and average exit timelines.",
      },
      {
        stage: "3. Interaction & Calculation",
        action: "Runs multiple stress tests on the Rental Yield & MC comparing hold vs. sell scenarios.",
        emoji: "📊",
        feeling: "Engaged & Validated",
        thinking: '"If interest rates rise another 0.5%, what does my net cash flow look like?"',
        touchpoints: "Yield & Mortgage Calculator toggle views",
        pain: "Calculators that only do basic gross yields rather than net yields.",
        opportunity: "Net yield toggle factoring in maintenance, void periods, and management costs.",
      },
      {
        stage: "4. Commitment / Action",
        action: "Books an Exit Strategy Portfolio Audit via the direct contact flow.",
        emoji: "🎯",
        feeling: "Decisive & Strategic",
        thinking: '"Let\'s get a professional valuation and structured exit roadmap."',
        touchpoints: "Portfolio appraisal CTA / Schedule consultation form",
        pain: "Vague contact forms that require repeating portfolio details over the phone.",
        opportunity: 'Targeted lead modal asking: "Number of units to review" & "Target exit timeframe".',
      },
      {
        stage: "5. Post-Action & Retention",
        action: "Reviews a bespoke portfolio disposal and equity realization proposal.",
        emoji: "🤝",
        feeling: "Relieved & Satisfied",
        thinking: '"Finally, a data-backed exit strategy that optimizes my capital gains."',
        touchpoints: "Proposal deck, Dedicated account manager",
        pain: "Drawn-out sales cycles with unvetted retail buyers.",
        opportunity: "Fast-track appraisal pipeline with high-priority turnaround for multi-unit portfolios.",
      },
    ],
  },
];

const rowLabels = [
  "User Action",
  "Feeling",
  "Thinking",
  "Touchpoints",
  "Pain Point / Friction",
  "UX Opportunity",
];

function JourneyCard({ j }: { j: Journey }) {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-full bg-[#0b172d] text-white flex items-center justify-center text-xs font-bold shrink-0">
            {j.name
              .split(" ")
              .map((n) => n[0])
              .slice(0, 2)
              .join("")}
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-[#202631]">
            {j.name} - {j.role}
          </h3>
        </div>
        <p className="text-sm text-[#4b5563] leading-6">
          <span className="font-semibold text-[#202631]">Scenario: </span>
          {j.scenario}
        </p>
        <p className="text-sm text-[#4b5563] leading-6 mt-2">
          <span className="font-semibold text-[#202631]">Goal: </span>
          {j.goal}
        </p>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[1100px] border border-[#eceef1] rounded-2xl overflow-hidden">
          <div className="grid grid-cols-[180px_repeat(5,1fr)] bg-[#0b172d] text-white">
            <div className="p-4 text-sm font-semibold">Stage</div>
            {j.stages.map((s) => (
              <div key={s.stage} className="p-4 text-sm font-semibold">
                {s.stage}
              </div>
            ))}
          </div>

          {rowLabels.map((label, rowIdx) => (
            <div
              key={label}
              className={`grid grid-cols-[180px_repeat(5,1fr)] ${
                rowIdx % 2 === 1 ? "bg-[#f6f7f9]" : "bg-white"
              }`}
            >
              <div className="p-4 text-sm font-semibold text-[#202631] border-t border-[#eceef1]">
                {label}
              </div>
              {j.stages.map((s) => {
                let content: React.ReactNode;
                switch (label) {
                  case "User Action":
                    content = s.action;
                    break;
                  case "Feeling":
                    content = (
                      <span>
                        <span className="text-2xl mr-1">{s.emoji}</span>
                        <span className="block mt-1">{s.feeling}</span>
                      </span>
                    );
                    break;
                  case "Thinking":
                    content = s.thinking;
                    break;
                  case "Touchpoints":
                    content = s.touchpoints;
                    break;
                  case "Pain Point / Friction":
                    content = s.pain;
                    break;
                  case "UX Opportunity":
                    content = s.opportunity;
                    break;
                }
                return (
                  <div
                    key={s.stage}
                    className="p-4 text-xs text-[#4b5563] leading-5 border-t border-[#eceef1]"
                  >
                    {content}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function UserJourneyMap() {
  return (
    <section>
      <SectionHeading>User Journey Map</SectionHeading>
      <div className="flex flex-col gap-20">
        {journeys.map((j) => (
          <JourneyCard key={j.name} j={j} />
        ))}
      </div>
    </section>
  );
}
