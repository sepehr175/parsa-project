import React from "react";

export default function DesignSystemSection() {
  return (
    <section className="flex flex-col items-center justify-center py-12 px-4 w-full">
      {/* تیتر بالای تصویر */}
      <h2
        className="text-[32px] sm:text-[40px] font-bold text-[#181949] text-center mb-8"
        style={{ fontFamily: "var(--font-cabinet)" }}
      >
        Design System
      </h2>

      {/* باکس تصویر با ابعاد ۱۲۶۰ در ۸۰۳ پیکسل در دسکتاپ */}
      <div className="w-full max-w-[1260px] h-auto lg:h-[803px] flex items-center justify-center overflow-hidden rounded-[24px] shadow-[0_4px_25px_rgba(0,0,0,0.05)] bg-white">
        <img
          src="/sm.png"
          alt="Design System"
          className="w-full h-full object-contain"
        />
      </div>
    </section>
  );
}
