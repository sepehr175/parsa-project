export default function WireframesSection() {
  return (
    <div className="relative w-full" style={{ height: "3374px" }}>
      <section
        className="absolute flex flex-col items-center"
        style={{
          top: "35px",
          left: "50%",
          transform: "translateX(-50%)",
          width: "1435px",
          height: "3374px",
        }}
      >
        {/* تیتر اصلی */}
        <h2
          className="text-[40px] font-bold text-[#000000] mb-[50px] text-center"
          style={{ fontFamily: "var(--font-cabinet, sans-serif)" }}
        >
          Wireframes
        </h2>

        {/* تصویر وایرفریم‌ها */}
        <div className="w-full flex-1 flex justify-center items-start overflow-hidden">
          <img
            src="/ns.webp"
            alt="Wireframes Layout"
            className="w-full h-full object-contain"
          />
        </div>
      </section>
    </div>
  );
}
