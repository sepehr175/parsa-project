import React from "react";

export default function WireframeSection() {
  return (
    <div className="w-full flex justify-center" style={{ marginTop: "160px" }}>
      <div
        className="overflow-hidden rounded-[24px]"
        style={{ width: "1175px", height: "861px", maxWidth: "100%", marginLeft: "5px" }}
      >
        <img
          src="/596ec1af704954212c071bacb0fa3b4791e71279.jpg"
          alt="Wireframe"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
}
