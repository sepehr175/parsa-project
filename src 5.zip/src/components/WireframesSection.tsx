export default function WireframesSection() {
  return (
    <section className="relative w-full min-w-0 lg:h-[3374px]">
      <div className="w-full flex flex-col items-center lg:absolute lg:top-[35px] lg:left-1/2 lg:-translate-x-1/2 lg:w-[1435px] lg:h-[3374px]">
        <h2
          className="text-[32px] sm:text-[36px] lg:text-[40px] font-bold text-[#000000] mb-7 sm:mb-9 lg:mb-[50px] text-center"
          style={{ fontFamily: "var(--font-cabinet, sans-serif)" }}
        >
          Wireframes
        </h2>

        <div className="w-full flex justify-center items-start overflow-hidden rounded-[16px] sm:rounded-[20px] lg:rounded-none lg:flex-1">
          <img
            src="/ns.webp"
            alt="Wireframes Layout"
            className="block w-full h-auto lg:w-full lg:h-full lg:object-contain"
          />
        </div>
      </div>
    </section>
  );
}
