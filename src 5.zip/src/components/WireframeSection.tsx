import React from "react";

export default function WireframeSection() {
  return (
    <section className="w-full flex justify-center mt-20 sm:mt-28 lg:mt-[160px] min-w-0">
      <div className="w-full lg:w-[1175px] aspect-[1175/861] lg:aspect-auto lg:h-[861px] overflow-hidden rounded-[18px] sm:rounded-[22px] lg:rounded-[24px] lg:ml-[5px]">
        <img
          src="/596ec1af704954212c071bacb0fa3b4791e71279.jpg"
          alt="Wireframe"
          className="w-full h-full object-cover"
        />
      </div>
    </section>
  );
}
