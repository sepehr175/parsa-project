import React from 'react';

export default function InformationArchitecture() {
  return (
    <section className="w-full min-w-0 flex flex-col items-start overflow-hidden">
      <h2 className="text-[28px] sm:text-[32px] md:text-[36px] font-bold text-[#1f2024] mb-6 sm:mb-8 tracking-tight text-left">
        Information Architecture
      </h2>
      <div className="w-full overflow-hidden lg:overflow-visible">
        <img
          src="/0ecec4c30e3b59c6d2739b61e55c20af0107178c.png"
          alt="Information Architecture Diagram"
          className="block w-full h-auto object-contain object-left md:max-w-full lg:w-[115%] lg:max-w-[1400px] lg:-ml-15"
        />
      </div>
    </section>
  );
}
