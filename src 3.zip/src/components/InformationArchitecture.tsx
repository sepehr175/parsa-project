import React from 'react';

export default function InformationArchitecture() {
  return (
    <div className="w-full flex flex-col items-start">
      <h2 className="text-[32px] md:text-[36px] font-bold text-[#1f2024] mb-8 tracking-tight text-left">
        Information Architecture
      </h2>
      <img
        src="/0ecec4c30e3b59c6d2739b61e55c20af0107178c.png"
        alt="Information Architecture Diagram"
        className="w-[110%] md:w-[115%] max-w-[1400px] h-auto object-contain object-left -ml-8 md:-ml-15"
      />
    </div>
  );
}
